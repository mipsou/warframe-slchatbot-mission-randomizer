




def timeDeltaToString(millis):
	
	if type(millis) != int:
		return '0'
	
	#build a day
	
	#build an hour
	
	#build a minute
	
	#add remaining seconds
	return timeString
	
def fromNow(d, now):
	#d - now
	return timeString
	
def toNow(d, now):
	#now - d
	return timeString
	
def parseDate(date)

	return timeString