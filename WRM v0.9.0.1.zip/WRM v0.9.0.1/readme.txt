

To install the script: 
	Start Streamlabs Chatbot
	Make sure you're connected
	Hit your scripts tab (requires connection)
	Open scripts folder
	Extract the WRM folder into your scripts folder


First Pass
-Toggle Special missions X
-Toggle mission Zones X
-Toggle mission Types X
-Hot reloading and recreate random list
	On save settings X
	On command request -
-Fetch data every X minutes ( defaults to 200 seconds ) X

Future thoughts:
-Settings changer commands
-Alert when any type of mission is about to rotate
-Level capping?
-Progress mode (track the casters progress)
-Event support
-Warframe info cmds
-Weapon info cmds
-News link cmds